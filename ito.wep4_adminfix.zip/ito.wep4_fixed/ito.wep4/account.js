const API_BASE = `${location.protocol}//${location.hostname}:3000`;
const PAID_PRODUCT_KEY = "book_paid";

async function api(path, opts = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    credentials: "include",
    ...opts,
  });
  const ct = res.headers.get("content-type") || "";
  const data = ct.includes("application/json") ? await res.json() : await res.text();
  if (!res.ok) throw new Error(typeof data === "string" ? data : (data.error || "REQUEST_FAILED"));
  return data;
}

const uName = document.getElementById("uName");
const booksEl = document.getElementById("books");
const logoutBtn = document.getElementById("logoutBtn");
const buyBox = document.getElementById("buyBox");
const requestBtn = document.getElementById("requestBtn");
const reqMsg = document.getElementById("reqMsg");
const adminLink = document.getElementById("adminLink");

function bookRow(title, desc, href) {
  const div = document.createElement("div");
  div.className = "book";
  div.innerHTML = `
    <div>
      <h3>${title}</h3>
      <p>${desc}</p>
    </div>
    <a class="btn btn--primary btn--sm" href="${href}">اقرأ</a>
  `;
  return div;
}

(async () => {
  try {
    const me = await api("/api/auth/me");
    if (!me.user) {
      window.location.href = "login.html";
      return;
    }

    uName.textContent = me.user.name || me.user.email;
    if (me.user.role === "admin") adminLink.style.display = "inline-flex";

    // Free book always
    booksEl.appendChild(bookRow("هل البرمجة طريقك؟ (مجاني)", "متاح لأي حد بدون تسجيل.", "free-book.html"));

    const my = await api("/api/user/my-books");
    const keys = (my.books || []).map((b) => b.product_key);
    const hasPaid = keys.includes(PAID_PRODUCT_KEY);

    if (hasPaid) {
      booksEl.appendChild(bookRow("برمجة من غير لخبطة (مدفوع)", "النسخة المدفوعة المتفعّلة على حسابك.", "book-paid.html"));
    } else {
      buyBox.style.display = "block";
    }
  } catch (e) {
    console.error(e);
    window.location.href = "login.html";
  }
})();

logoutBtn.addEventListener("click", async () => {
  try {
    await api("/api/auth/logout", { method: "POST" });
  } catch (_) {}
  window.location.href = "index.html";
});

requestBtn?.addEventListener("click", async () => {
  reqMsg.textContent = "جارٍ إرسال الطلب...";
  try {
    await api("/api/user/request-purchase", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ product_key: PAID_PRODUCT_KEY }),
    });
    reqMsg.textContent = "✅ تم تسجيل طلب التفعيل. الأدمن هيراجعه ويوافق عليه.";
  } catch (e) {
    reqMsg.textContent = "❌ حصلت مشكلة. جرّب تاني.";
  }
});
